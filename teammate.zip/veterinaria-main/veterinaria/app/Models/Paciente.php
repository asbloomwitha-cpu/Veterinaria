<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Paciente extends Model
{
    use HasFactory;

    protected $fillable = [
        'user_id',
        'nombre',
        'especie',
        'raza',
        'edad',
        'nombre_propietario',
        'telefono_propietario',
        'observaciones',
    ];

    public function user()
    {
        return $this->belongsTo(User::class);
    }
}
